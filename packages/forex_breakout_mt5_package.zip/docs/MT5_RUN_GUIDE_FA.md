# راهنمای اجرای ربات در MetaTrader 5

> هشدار مهم: این پروژه ابزار پژوهش و بک تست است، نه تضمین سود. قبل از حساب واقعی، حتما
> روی Strategy Tester و حساب Demo تست بگیر. در بازار واقعی اسپرد، اسلیپیج، سرعت اجرا،
> خبرهای اقتصادی و قطعی VPS می تواند نتیجه را تغییر دهد.

## نسخه پیشنهادی فعلی

بهترین نسخه فعلی از بک تست ها:

- تایم فریم: `H4`
- جفت ارزهای پیشنهادی برای دمو:
  - `EURUSD`
  - `AUDUSD`
  - `GBPUSD`
  - `NZDUSD` فقط با احتیاط بیشتر، چون در تست های قبلی گاهی ضعیف تر بود.
- ریسک پیشنهادی شروع دمو: `0.5%` تا `1%` در هر معامله
- نوع استراتژی: شکست/پول بک با فیلتر ATR، EMA، RSI، ADX، بدنه کندل و شکست چندکندلی

## فایل های مهم

- Expert Advisor برای MT5:
  - `mt5/Experts/ForexBreakoutPullbackEA.mq5`
- پارامتر نهایی بک تست شده:
  - `config/final_4h_three_pair_params.json`
- preset آماده برای MT5:
  - `mt5/Presets/H4_Breakout_Pullback_Recommended.set`
- خلاصه نتیجه نهایی:
  - `results/focused_final_package_summary.json`

## نصب در MT5

1. MetaTrader 5 را نصب کن.
2. از منوی MT5 برو به:
   - `File -> Open Data Folder`
3. وارد این مسیر شو:
   - `MQL5/Experts`
4. فایل زیر را داخل آن کپی کن:
   - `ForexBreakoutPullbackEA.mq5`
5. MT5 را ببند و دوباره باز کن، یا در Navigator راست کلیک کن و `Refresh` بزن.
6. از منو `Tools -> MetaQuotes Language Editor` را باز کن.
7. فایل Expert را باز کن و `Compile` بزن.
8. اگر compile بدون error بود، ربات آماده تست است.

## بک تست در Strategy Tester

1. در MT5 کلید `Ctrl+R` را بزن.
2. Expert را انتخاب کن:
   - `ForexBreakoutPullbackEA`
3. Symbol را انتخاب کن، مثلا:
   - `EURUSD`
4. تایم فریم:
   - `H4`
5. Model:
   - اگر بروکر اجازه می دهد: `Every tick based on real ticks`
   - اگر نه: `Every tick`
6. Deposit:
   - `1000 EUR` یا نزدیک به سرمایه واقعی خودت
7. Leverage:
   - ترجیحا محافظه کارانه، مثلا `1:20` یا کمتر
8. تاریخ تست:
   - تا جای ممکن طولانی، حداقل 1 تا 2 سال
9. در Inputs این موارد را چک کن:
   - اگر خواستی سریع تنظیم کنی، دکمه `Load` را بزن و این preset را انتخاب کن:
     - `H4_Breakout_Pullback_Recommended.set`
   - `InpRiskPercent = 0.5` یا `1.0`
   - `InpMaxSpreadPips = 2.0`
   - `InpShowChartPanel = true` برای نمایش پنل روی چارت
   - `InpOwnerName = pedram kamangar`
   - بقیه پارامترها پیش فرض همین نسخه نهایی هستند.
10. `Start` را بزن.

## اجرای دمو

1. یک حساب Demo MT5 باز کن.
2. نمودار `EURUSD` را باز کن.
3. تایم فریم را روی `H4` بگذار.
4. ربات را از Navigator روی نمودار Drag کن.
5. تیک `Allow Algo Trading` را فعال کن.
6. در بالای MT5 دکمه `Algo Trading` باید روشن باشد.
7. همین کار را برای `AUDUSD` و `GBPUSD` هم می توانی انجام بدهی.
8. برای هر نمودار، Magic Number متفاوت بگذار یا همین Magic را نگه دار اگر فقط یک ربات روی هر symbol داری.

## پنل نمایشی روی چارت

نسخه MT5 یک پنل بالا-چپ چارت نمایش می دهد که شامل این موارد است:

- لوگوی رنگی `DRAGON FX`
- نام مالک: `pedram kamangar`
- متن وضعیت: `Robot is active and monitoring the strategy.`
- وضعیت وظیفه ربات:
  - اگر معامله باز نباشد: در حال اسکن سیگنال های H4
  - اگر معامله باز باشد: در حال مدیریت معامله باز
- symbol، تایم فریم، درصد ریسک و اسپرد فعلی
- وضعیت اجازه معامله خودکار در ترمینال

اگر نخواستی پنل دیده شود، در Inputs مقدار `InpShowChartPanel` را `false` کن.
اگر متن وضعیت را خواستی تغییر بدهی، مقدار `InpPanelStatusText` را عوض کن.

## لاگ عیب یابی اگر معامله باز نمی شود

برای اینکه بفهمی چرا ربات معامله باز نمی کند:

1. در Inputs مقدار `InpEnableDiagnostics` را `true` بگذار.
2. ربات را روی چارت یا Strategy Tester اجرا کن.
3. در MT5 پایین صفحه تب های زیر را ببین:
   - `Experts`
   - `Journal`
4. پیام هایی که با `[FBP_DIAG]` شروع می شوند را بررسی کن.

لاگ ها این موارد را نشان می دهند:

- Tick received
- Timeframe check passed/failed
- New-bar gate passed/failed
- Max positions check
- Session filter
- Spread filter
- News filter status
- Cooldown timer status
- Indicator data check
- Trend check
- ADX/body quality check
- RSI threshold check
- Breakout/pullback check
- Signal generated yes/no
- Order attempt yes/no
- OrderSend result and retcode

### تست اجباری فقط برای Demo

اگر می خواهی مطمئن شوی مشکل از اجازه معامله/بروکر نیست:

1. فقط روی حساب Demo استفاده کن.
2. در Inputs بگذار:
   - `ForceTestTrade = true`
3. ربات بعد از initialization، روی اولین tick مناسب فقط یک سفارش market با حجم دقیق `0.01 lot` تلاش می کند باز کند.
4. اگر حساب Demo نباشد، هیچ معامله ای باز نمی کند و در لاگ می نویسد blocked.
5. اگر بروکر حجم دقیق `0.01` را اجازه ندهد، معامله باز نمی کند و در لاگ دلیل را می نویسد.
6. اگر سفارش با موفقیت باز شد، ForceTestTrade به صورت داخلی دیگر تکرار نمی شود.

بعد از تست، دوباره `ForceTestTrade = false` کن.

## پیشنهاد تنظیم ریسک

برای شروع:

- حساب Demo: `InpRiskPercent = 1.0`
- حساب واقعی کوچک: `InpRiskPercent = 0.25` تا `0.5`
- اگر drawdown واقعی از بک تست بیشتر شد، ربات را متوقف کن.

## نکته مهم درباره ساعت معاملات

پارامترهای `InpSessionStartHour` و `InpSessionEndHour` در MT5 بر اساس ساعت سرور
بروکر هستند. داده Yahoo در بک تست Python عملا با زمان UTC کار می کند، اما بروکر
ممکن است UTC+2، UTC+3 یا زمان دیگری داشته باشد. پس در Strategy Tester بروکر خودت
حتما این دو پارامتر را هم تست کن. اگر معاملات خیلی کم یا خیلی بد شد، بازه را به
`0` تا `24` یا مطابق سشن لندن/نیویورک بروکر تنظیم کن.

## قوانین توقف دستی

ربات را متوقف کن اگر:

- اسپرد جفت ارزها زیاد شد.
- نزدیک خبرهای مهم مثل NFP، CPI، نرخ بهره هستی.
- 3 تا 5 ضرر پشت سر هم در یک symbol رخ داد.
- drawdown حساب از حد تحمل تو بیشتر شد.
- VPS یا اینترنت ناپایدار است.

## انتخاب بروکر مناسب

من به جای تبلیغ یک بروکر خاص، معیارهای انتخاب می دهم:

1. حتما MT5 واقعی داشته باشد.
2. اجازه Expert Advisor و Algo Trading بدهد.
3. روی EURUSD/AUDUSD/GBPUSD اسپرد پایین داشته باشد.
4. حساب ECN/Raw Spread با کمیسیون شفاف بهتر است.
5. رگوله معتبر داشته باشد، مثلا تحت نهادهای شناخته شده مثل FCA، ASIC، CySEC یا معادل معتبر کشور خودت.
6. VPS نزدیک سرور بروکر ارائه کند یا با VPS خارجی latency پایین داشته باشد.
7. در زمان خبرها اجرای سفارش را محدود یا غیرعادی نکند.
8. اول با حساب Demo و بعد با حساب Cent/Micro شروع کن.

قبل از واریز پول واقعی، نام بروکر را در سایت رگولاتور مربوطه چک کن. فقط به تبلیغات سایت بروکر اعتماد نکن.

## نکات مهم درباره اجرای تمام اتوماتیک

- MT5 باید روشن باشد یا روی VPS اجرا شود.
- Algo Trading باید روشن باشد.
- ربات فقط روی نمودارهایی کار می کند که روی آن ها attach شده باشد.
- برای اجرای 24/5 بهتر است VPS استفاده کنی.
- ربات در این نسخه به تقویم خبری وصل نیست؛ زمان خبرهای بزرگ بهتر است دستی خاموش شود.

## پیشنهاد استفاده فعلی

برای شروع دمو:

1. فقط `EURUSD H4` را فعال کن.
2. بعد از 2 تا 4 هفته دمو، اگر رفتار مشابه بک تست بود، `AUDUSD H4` را اضافه کن.
3. بعد `GBPUSD H4` را اضافه کن.
4. `NZDUSD H4` را فقط اگر در Strategy Tester بروکر خودت مثبت بود فعال کن.
